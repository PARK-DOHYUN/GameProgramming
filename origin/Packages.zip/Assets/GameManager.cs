﻿using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    [Header("Timer Settings")]
    public float timeLimit = 10f;
    private float timer;
    private bool isEnd = false;

    [Header("UI")]
    public TextMeshProUGUI timerText;
    public GameObject resultPanel;
    public TextMeshProUGUI resultTitleText;
    public TextMeshProUGUI resultTimeText;
    public TextMeshProUGUI restartText;

    void Awake()
    {
        Instance = this;
    }

    void Start()
    {
        timer = timeLimit;
        resultPanel.SetActive(false);
        restartText.gameObject.SetActive(false);

        // 혹시 이전 플레이에서 timeScale이 0이었다면 복구
        Time.timeScale = 1f;
    }

    void Update()
    {
        if (!isEnd)
        {
            timer -= Time.deltaTime;
            timerText.text = "Time Left: " + timer.ToString("F2");

            if (timer <= 0)
            {
                timer = 0;
                GameOver(false);
            }
        }
        else
        {
            // R로 다시 시작
            if (Input.GetKeyDown(KeyCode.R))
            {
                Time.timeScale = 1f;  // ← 가장 중요한 부분! 복구
                SceneManager.LoadScene(SceneManager.GetActiveScene().name);
            }
        }
    }

    public void ReachGoal()
    {
        GameOver(true);
    }

    private void GameOver(bool isSuccess)
    {
        isEnd = true;

        Time.timeScale = 0f; // 게임 정지

        resultPanel.SetActive(true);
        restartText.gameObject.SetActive(true);

        if (isSuccess)
        {
            resultTitleText.text = "SUCCESS!";
            float clearTime = timeLimit - timer;
            resultTimeText.text = "Clear Time: " + clearTime.ToString("F2") + "s";
        }
        else
        {
            resultTitleText.text = "FAILED!";
            resultTimeText.text = "Out of Time!";
        }
    }
}
